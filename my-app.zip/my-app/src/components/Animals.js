import React, {Component} from 'react';
import {Button} from 'react-bootstrap' ;
import {ModalPopup} from './ModalPopup';
import axios from 'axios';

import {List} from './List'
export class Animals extends Component{
     constructor(props){
         super(props);
         this.getAnimlasData();
         this.state={deps:[],modalShow:false,
            shop:[]
        }
     }
     getAnimlasData() {
        axios.get(`http://styleguide.effectivedigital.com/interview/api/animals`)
          .then(res => {
            const shop = res.data;
            this.setState({ shop });
          })
      }
    
    
    
    render(){
            return (
                this.state.shop.map((item, key) =>
                <List item={item} key={item.id} />
                )
            )
        //let modalPopupClose=()=> this.setState({modalShow:false});
    }
}