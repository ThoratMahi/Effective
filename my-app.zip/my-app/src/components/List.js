import React, {Component} from 'react';
import {Button} from 'react-bootstrap' ;
export class List extends Component {
    openModalPopup(){
        console.log("fdsfsdfsdfsdf");
    }
    render() {
        return (
            <div className="panel panel-primary" >
                <div className="panel-heading">
                    <h3 className="panel-title"> {this.props.item.Title}</h3>                    
                </div>
                <div className="panel-body">
                    <div className="col-xs-12 col-md-12 col-sm-4">
                    <div className="row vertical-align">
                            
                        <div className="col-xs-1 col-md-2 col-sm-4">
                            <img className="imageClass" onClick={this.openModalPopup} src={this.props.item.ImageURLs.Thumb} />
                        </div>
                        <div className="col-xs-11  col-md-10 col-sm-4 ">
                                <strong>Desciption: </strong>
                                {this.props.item.Description}
                        </div>
            
                    </div>
                    </div>

                </div>
            </div>
        );
    }
}
