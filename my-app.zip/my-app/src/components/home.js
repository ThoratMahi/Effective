import React, { Component } from 'react';

class home extends Component {
    render(){
        return (
            <div class="container">
                <nav class="navbar navbar-default">
                <ul class="nav navbar-nav">
                    <li>
                        <a routerLink="list">List</a>
                    </li>
                    <li>
                        <a routerLink="create">Create</a>
                    </li>
                </ul>
                </nav>
                <router-outlet></router-outlet>
                </div>
        )
    }
} 
export default home